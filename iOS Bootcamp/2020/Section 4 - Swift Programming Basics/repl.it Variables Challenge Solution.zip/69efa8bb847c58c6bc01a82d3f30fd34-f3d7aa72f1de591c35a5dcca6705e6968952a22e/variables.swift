var a = 5
var b = 8

var c = a
a = b
b = c

print("a: \(a)")
print("b: \(b)")



