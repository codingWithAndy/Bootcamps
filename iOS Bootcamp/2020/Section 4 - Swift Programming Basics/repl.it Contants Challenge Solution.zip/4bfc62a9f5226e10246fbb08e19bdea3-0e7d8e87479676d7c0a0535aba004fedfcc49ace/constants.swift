//Write your code here.

// Solution
let secondsInAnHour = 3600

// alternatively:
// let secondsInAnHour: Int = 3600

// Note, constants can only be set once and cannot be assigned a new value. 
// The below does not work, because it is a constant and thus cannot be changed.
// secondsInAnHour = 1337



//Don't change the code below.
print(secondsInAnHour)