
![App Brewery Banner](Documentation/AppBreweryBanner.png)

#  I Am Poor

## Our Goal

The objective of this challenge is to make sure you are comfortable with using the storyboard and designing your own UI elements. We want to make sure that everything we covered in the last tutorial is clear and you’ll be able to do it by yourself without help.

## What you will create

Now that you have been rich, it’s time to join the 99%. This app will proudly display a lump of coal and the statement “I Am Poor”; the perfect app for when you get asked for money on the streets. 

>This is a companion project to The App Brewery's Complete App Developement Bootcamp, check out the full course at [www.appbrewery.co](https://www.appbrewery.co/)

![End Banner](Documentation/readme-end-banner.png)
