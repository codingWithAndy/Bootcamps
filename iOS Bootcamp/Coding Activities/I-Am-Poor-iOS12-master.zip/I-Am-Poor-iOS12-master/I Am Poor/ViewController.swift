//
//  ViewController.swift
//  I Am Poor
//
//  Created by Angela Yu on 24/08/2016.
//
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }



}

